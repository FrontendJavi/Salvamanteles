package com.example.salvamanteles;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.regex.Pattern;

public class ForgotActivity extends AppCompatActivity {

    EditText PasswordeditText;
    TextView tv1, tv2, tv3, tv4;
    Button Registerbutton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot);

        Registerbutton = findViewById(R.id.Registerbutton);
        PasswordeditText = findViewById(R.id.PasswordeditText);
        tv1 = findViewById(R.id.tv1);
        tv2 = findViewById(R.id.tv2);
        tv3 = findViewById(R.id.tv3);
        tv4 = findViewById(R.id.tv4);

        PasswordeditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String pass = PasswordeditText.getText().toString();
                validatePassword(pass);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });


        Registerbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Register.class);
                startActivity(intent);
            }
        });

    }

    public void validatePassword(String password) {
        Pattern upperCase = Pattern.compile("[A-Z]");
        Pattern lowerCase = Pattern.compile("[a-z]");
        Pattern digitCase = Pattern.compile("[0-9]");

        if (!lowerCase.matcher(password).find()) {
            tv1.setTextColor(Color.WHITE);

        } else {
            tv1.setTextColor(Color.GREEN);
        }


        if(!upperCase.matcher(password).find()){
            tv2.setTextColor(Color.WHITE);
        } else {
            tv2.setTextColor(Color.GREEN);
        }

        if(!digitCase.matcher(password).find()){
            tv3.setTextColor(Color.WHITE);
        } else {
            tv3.setTextColor(Color.GREEN);
        }

        if (password.length() < 8){
            tv4.setTextColor(Color.WHITE);
        } else {
            tv4.setTextColor(Color.GREEN);
        }


    }
}