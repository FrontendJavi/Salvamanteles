package com.example.salvamanteles;

public class Login {

        String email;
        String password;


}
