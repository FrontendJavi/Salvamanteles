package com.example.salvamanteles;

import androidx.appcompat.app.AppCompatActivity;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.regex.Pattern;


public class MainActivity extends AppCompatActivity {           // En este layout se hace el login

    EditText EmailEditText;
    EditText PasswordEditText;
    Button ForgottenButton;
    Button LoginButton;
    Button RegisterButton;
    TextView tv1, tv2, tv3, tv4;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        setContentView(R.layout.activity_main);

        // descomenta esto cuando la api furule

   //     Retrofit retrofit = new Retrofit.Builder()
        //        .baseUrl("url base, terminada en api/")
       //         .addConverterFactory(GsonConverterFactory.create()).build();
     //   final Api api = retrofit.create(Api.class);

        String token = cargarToken();
        if (token == "") {
            //aqui ha fallado al cargar el token
        } else {
            //aqui no
        }


        EmailEditText = (EditText) findViewById(R.id.EmaileditText);
        PasswordEditText = (EditText) findViewById(R.id.PasswordeditText);
        ForgottenButton = (Button) findViewById(R.id.Forgotbutton);
        LoginButton = (Button) findViewById(R.id.Loginbutton);
        RegisterButton = (Button) findViewById(R.id.Registerbutton);






        LoginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String verificar = EmailEditText.getText().toString();
                String verificar2 = PasswordEditText.getText().toString();

                if(verificar.isEmpty()) {

                    EmailEditText.setError("Campo vacío");
                } else if( verificar2.isEmpty()) {
                    PasswordEditText.setError("Campo vacío");
                } else {

                    Intent intent = new Intent(getApplicationContext(), MainScreen.class);
                    startActivity(intent);
                }



            }
        });

        ForgottenButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), ForgotActivity.class);
                startActivity(intent);
            }
        });

        RegisterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Register.class);
                startActivity(intent);
            }
        });



    }


    void HacerLogin(){          // poner en el clicklistener de boton de login cuando furule la api

        Retrofit retrofit = new Retrofit.Builder()                              // quitar esta linea al implementarlo
                .baseUrl("url base, terminada en api/")                         // y esta
                .addConverterFactory(GsonConverterFactory.create()).build();    // esta tambien
        final Api api = retrofit.create(Api.class);                             // al igual que esta

        Call<Login> login = api.login(String.valueOf(EmailEditText.getText()), String.valueOf(PasswordEditText.getText()));     // esta no xd
        login.enqueue(new Callback<Login>() {
            @Override
            public void onResponse(Call<Login> call, Response<Login> response) {
                // AQUI EL SERVIDOR HA DEVUELTO 200
            }

            @Override
            public void onFailure(Call<Login> call, Throwable t) {
                // AQUI HA DEVUELTO QUE LA AUTENTICACION FALLA O QUE NO SE HA PODIDO CONECTAR CON EL SERVIDOR
            }
        });


    }

    void guardarToken(String token){

        SharedPreferences preferences = getSharedPreferences("token_salavamanteles",
                Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("token", token);
        editor.commit();
    }

    String cargarToken(){
        SharedPreferences preferences = getSharedPreferences("token_salvamanteles",
                Context.MODE_PRIVATE);
        String token = preferences.getString("token", "");

        return token;

    }



}
